The images contained in these folders come from the following sets:

•	AI Generated Faces from Generated.Photos
https://generated.photos
•	Turath-150K Image Database of Arab Heritage
https://danikiyasseh.github.io/Turath/
•	ANIMAL-10N Dataset
https://dm.kaist.ac.kr/datasets/animal-10n/
Song, H., Kim, M., and Lee, J., "SELFIE: Refurbishing Unclean Samples for Robust Deep Learning" In Proc. 36th Int'l Conf. on Machine Learning (ICML), Long Beach, California, June 2019
